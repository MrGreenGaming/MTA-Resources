local peak = 0

function playerJoin()
	local current = getPlayerCount()
	if tonumber(current) > tonumber(peak) then
		-- New record, give everyone points
		outputDebugString(get("greencoinsamount"));
		for i,p in ipairs(getElementsByType("player")) do
			exports.gc:addPlayerGreencoins(p, tonumber(get("greencoinsamount")))
		end
		peak = current
		local file = xmlCreateFile("peak.xml", "peak")
		local node = xmlCreateChild(file, "currentRecord", 0)
		xmlNodeSetValue(node, tonumber(peak))
		local attr = getTime();
		xmlNodeSetAttribute(node, "time", attr)
		local s = xmlSaveFile(file)
		if not s then
			outputDebugString("[Peak] Unable to save file!")
		end
		
	end
end
addEventHandler("onPlayerJoin", getRootElement(), playerJoin)

function startResource()
	outputDebugString("[Peak] Starting resource...")
	local file = xmlLoadFile("peak.xml")
	if not file then
		outputDebugString("[Peak] File not found, creating...")
		file = xmlCreateFile("peak.xml", "peak")
		local node = xmlCreateChild(file, "currentRecord")
		xmlNodeSetValue(node, 0)
		xmlSaveFile(file)
	end
	local node = xmlFindChild(file, "currentRecord", 0)
	peak = xmlNodeGetValue(node)
	
	outputDebugString("[Peak] Current peak: " .. peak)
end
addEventHandler("onResourceStart", getResourceRootElement(), startResource)

function getTime()
	local t = getRealTime()
	local datetime = string.format("%04d-%02d-%02d %02d:%02d:%02d", t.year + 1900, t.month + 1, t.monthday, t.hour, t.minute, t.second)
	return datetime
end