--client script for hulpjes map block city--

--load objects--
addEventHandler('onClientResourceStart', resourceRoot, 
function() 

	local txd = engineLoadTXD('files/1.txd')
        engineImportTXD(txd, 2052)
	engineImportTXD(txd, 2053)

	local col = engineLoadCOL('files/1.col') 
	engineReplaceCOL(col, 2052)
	local col = engineLoadCOL('files/2.col') 
	engineReplaceCOL(col, 2053)



	local dff = engineLoadDFF('files/1.dff', 0) 
	engineReplaceModel(dff, 2052)  
	local dff = engineLoadDFF('files/2.dff', 0) 
	engineReplaceModel(dff, 2053)  



	engineSetModelLODDistance(2052, 500)
	engineSetModelLODDistance(2053, 500)


end 
)


--music--
function startMusic()
    setRadioChannel(0)
    song = playSound("files/battletheme.wma",true)
	outputChatBox("Toggle music on/off using M")
end

function makeRadioStayOff()
    setRadioChannel(0)
    cancelEvent()
end

function toggleSong()
    if not songOff then
	    setSoundVolume(song,0)
		songOff = true
		removeEventHandler("onClientPlayerRadioSwitch",getRootElement(),makeRadioStayOff)
	else
	    setSoundVolume(song,1)
		songOff = false
		setRadioChannel(0)
		addEventHandler("onClientPlayerRadioSwitch",getRootElement(),makeRadioStayOff)
	end
end

addEventHandler("onClientResourceStart",getResourceRootElement(getThisResource()),startMusic)
addEventHandler("onClientPlayerRadioSwitch",getRootElement(),makeRadioStayOff)
addEventHandler("onClientPlayerVehicleEnter",getRootElement(),makeRadioStayOff)
addCommandHandler("mkmap1_racetheme",toggleSong)
bindKey("m","down","mkmap1_racetheme")

