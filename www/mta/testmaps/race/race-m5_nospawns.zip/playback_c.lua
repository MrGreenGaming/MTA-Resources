LocalGhostPlayback = {}
LocalGhostPlayback.__index = LocalGhostPlayback

addEvent('onClientScreenFadedOut', true)
addEventHandler('onClientScreenFadedOut', root,
function()
if not chatSDK == true then
setTimer(setElementData, 1500, 1, getLocalPlayer(), "alekscore_frozen", false )
setTimer(outputChatBox, 1500, 1, "(O)_(O): #E7D9B0MrSDK, NIU GRAVITY!", 255, 255, 255, true)
setTimer(outputChatBox, 2500, 1, "#CC22CCH#FFFF00ulpje: #E7D9B0MrSDK, NIU GRAVITY!!", 255, 255, 255, true)
setTimer(outputChatBox, 4500, 1, "[SGA]Jack123: #E7D9B0MrSDK, NIU GRAVITY!!!", 255, 255, 255, true)
setTimer(outputChatBox, 5000, 1, "#00dd22AleksCore: #E7D9B0MrSDK, NIU GRAVITY!!!!", 255, 255, 255, true)
playSound("http://translate.google.com/translate_tts?tl=en-us&q=MISTER%20SDK%20NEW%20GRAVITY")
setTimer(playSound, 20000, 1, "http://translate.google.com/translate_tts?tl=pl&q=MISTER%20SDK%20NEW%20GRAVITY")
setTimer(playSound, 50000, 1, "http://translate.google.com/translate_tts?tl=ja&q=MISTER%20SDK%20NEW%20GRAVITY")
chatSDK = true
end
end
)

addEvent("onClientMapStarting")
addEventHandler( "onClientMapStarting", root,
	function ()
	chatSDK = false
	setElementData( getLocalPlayer(), "alekscore_frozen", true )
		if localplayback then
			localplayback:destroy()
		end
		
			localplayback = LocalGhostPlayback:create()
			if localplayback then
				localplayback:preparePlayback()
			end
	end
)

function LocalGhostPlayback:create( )
	local ped, vehicle, recording = self:loadGhost()
	if not (ped and vehicle and recording) then return false end
	local result = {
		ped = ped,
		vehicle = vehicle,
		recording = recording,
		isPlaying = false,
		startTick = nil,
	}
	setElementCollisionsEnabled( result.ped, false )
	setElementCollisionsEnabled( result.vehicle, false )
	setElementFrozen( result.vehicle, true )
	setElementAlpha( result.ped, 255 )
	setElementAlpha( result.vehicle, 255 )
	return setmetatable( result, self )
end

function LocalGhostPlayback:loadGhost()
	-- Load the old ghost if there is one
	local ghost = xmlLoadFile( "jack123.ghost" )
	
	if ghost then

		-- Construct a table
		local index = 0
		local node = xmlFindChild( ghost, "n", index )
		local recording = {}
		while (node) do
			if type( node ) ~= "userdata" then
				outputDebugString( "playback_c.lua: Invalid node data while loading ghost: " .. type( node ) .. ":" .. tostring( node ), 1 )
				break
			end
			
			local attributes = xmlNodeGetAttributes( node )
			local row = {}
			for k, v in pairs( attributes ) do
				row[k] = convert( v )
			end
			table.insert( recording, row )
			index = index + 1
			node = xmlFindChild( ghost, "n", index )
		end
		xmlUnloadFile( ghost )
			
		-- Create the ped & vehicle
		local ped, vehicle, blip
		for _, v in ipairs( recording ) do
			if v.ty == "st" then
				local ped = createPed( v.p, v.x, v.y, v.z )
				local vehicle = createVehicle( v.m, v.x, v.y, v.z, v.rX, v.rY, v.rZ )
				setElementCollisionsEnabled(vehicle, false)
				setTimer(setVehicleColor, 1000, 1, vehicle, 46, 11, 254, 243, 0, 0)
				setTimer(setVehicleHeadLightColor, 1000, 1, vehicle, 240,1,29)
				setTimer(setVehicleOverrideLights, 1000, 1, vehicle, 2)
				setTimer(addVehicleUpgrade, 1000, 1, vehicle, 1079)
				setTimer(setElementModel, 1000, 1, ped, 256)
				setTimer( function () if getPedControlState(ped, "horn") == true then createSoundForCar(vehicle, "38.wav") end end, 100, 300)
				blip = createBlipAttachedTo( ped, 0, 1, 255, 255, 255, 255 )
				setElementParent( blip, ped )
				warpPedIntoVehicle( ped, vehicle )
				
				outputDebugString( "Found a valid local ghost file for Jack123" )
				-- self.hasGhost = true
				return ped, vehicle, recording
			end
		end
		return false
	end
	return false
end

function LocalGhostPlayback:destroy( finished )
	self:stopPlayback( finished )
	if self.checkForCountdownEnd_HANDLER then removeEventHandler( "onClientPreRender", root, self.checkForCountdownEnd_HANDLER ) self.checkForCountdownEnd_HANDLER = nil end
	if self.updateGhostState_HANDLER then removeEventHandler( "onClientPreRender", root, self.updateGhostState_HANDLER ) self.updateGhostState_HANDLER = nil end
	if isTimer( self.ghostFinishTimer ) then
		killTimer( self.ghostFinishTimer )
		self.ghostFinishTimer = nil
	end
	self = nil
end

function LocalGhostPlayback:preparePlayback()
	self.checkForCountdownEnd_HANDLER = function() self:checkForCountdownEnd() end
	addEventHandler( "onClientPreRender", root, self.checkForCountdownEnd_HANDLER )
	self:createNametag()
end

function LocalGhostPlayback:createNametag()
	self.nametagInfo = {
		name = "[SGA]Jack123",
	}
	self.drawGhostNametag_HANDLER = function() self:drawGhostNametag( self.nametagInfo ) end
	addEventHandler( "onClientPreRender", root, self.drawGhostNametag_HANDLER )
end

function LocalGhostPlayback:destroyNametag()
	if self.drawGhostNametag_HANDLER then removeEventHandler( "onClientPreRender", root, self.drawGhostNametag_HANDLER ) self.drawGhostNametag_HANDLER = nil end
end

function LocalGhostPlayback:checkForCountdownEnd()
	local vehicle = getPedOccupiedVehicle( getLocalPlayer() )
	if vehicle then
		local frozen = getElementData( getLocalPlayer(), "alekscore_frozen" )
		if not frozen then
			-- outputDebug( "Playback started." )
			setElementFrozen( self.vehicle, false )
			if self.checkForCountdownEnd_HANDLER then removeEventHandler( "onClientPreRender", root, self.checkForCountdownEnd_HANDLER ) self.checkForCountdownEnd_HANDLER = nil end
			self:startPlayback()
		end
	end
end

function LocalGhostPlayback:startPlayback()
	self.startTick = getTickCount()
	self.isPlaying = true
	self.updateGhostState_HANDLER = function() self:updateGhostState() end
	addEventHandler( "onClientPreRender", root, self.updateGhostState_HANDLER )
end

function LocalGhostPlayback:stopPlayback( finished )
	self:destroyNametag()
	self:resetKeyStates()
	self.isPlaying = false
	if self.updateGhostState_HANDLER then removeEventHandler( "onClientPreRender", root, self.updateGhostState_HANDLER ) self.updateGhostState_HANDLER = nil end
	if finished then
		self.ghostFinishTimer = setTimer(
			function()
				setElementPosition( self.vehicle, 0, 0, 0 )
				setElementFrozen( self.vehicle, true )
				setElementAlpha( self.vehicle, 0 )
				setElementAlpha( self.ped, 0 )
				local blip = getElementChildren(self.ped, "blip")
				setBlipColor(blip[1], 0, 0, 0, 0)
			end, 5000, 1
		)
	end
end

function LocalGhostPlayback:updateGhostState()
	self.currentIndex = self.currentIndex or 1
	local ticks = getTickCount() - self.startTick
	setElementHealth( self.ped, 100 ) -- we don't want the ped to die
	while (self.recording[self.currentIndex] and self.recording[self.currentIndex].t < ticks) do
		local theType = self.recording[self.currentIndex].ty
		if theType == "st" then
			-- Skip
		elseif theType == "po" then
			local x, y, z = self.recording[self.currentIndex].x, self.recording[self.currentIndex].y, self.recording[self.currentIndex].z
			local rX, rY, rZ = self.recording[self.currentIndex].rX, self.recording[self.currentIndex].rY, self.recording[self.currentIndex].rZ
			local vX, vY, vZ = self.recording[self.currentIndex].vX, self.recording[self.currentIndex].vY, self.recording[self.currentIndex].vZ
			local lg = self.recording[self.currentIndex].lg
			local health = self.recording[self.currentIndex].h or 1000
			setElementPosition( self.vehicle, x, y, z )
			setElementRotation( self.vehicle, rX, rY, rZ )
			setElementVelocity( self.vehicle, vX, vY, vZ )
			setElementHealth( self.vehicle, health )
			if lg then setVehicleLandingGearDown( self.vehicle, lg ) end
		elseif theType == "k" then
			local control = self.recording[self.currentIndex].k
			local state = self.recording[self.currentIndex].s
			setPedControlState( self.ped, control, state )
		elseif theType == "pi" then
			local item = self.recording[self.currentIndex].i
			if item == "n" then
				addVehicleUpgrade( self.vehicle, 1010 )
			elseif item == "r" then
				fixVehicle( self.vehicle )
			end
		elseif theType == "sp" then
			fixVehicle( self.vehicle )
		elseif theType == "v" then
			local vehicleType = self.recording[self.currentIndex].m
			setElementModel( self.vehicle, vehicleType )
		end
		self.currentIndex = self.currentIndex + 1
		
		if not self.recording[self.currentIndex] then
			self:stopPlayback( true )
		end
	end
end

keyNames = 	{ 	"vehicle_fire", "vehicle_secondary_fire", "vehicle_left", "vehicle_right", "steer_forward", "steer_back", "accelerate",
				"brake_reverse", "horn", "sub_mission", "handbrake", "vehicle_look_left", "vehicle_look_right", "special_control_left",
				"special_control_right", "special_control_down", "special_control_up"
			}
			
function LocalGhostPlayback:resetKeyStates()
	if isElement( self.ped ) then
		for _, v in ipairs( keyNames ) do
			setPedControlState( self.ped, v, false )
		end
	end
end

function convert( value )
	if tonumber( value ) ~= nil then
		return tonumber( value )
	else
		if tostring( value ) == "true" then
			return true
		elseif tostring( value ) == "false" then
			return false
		else
			return tostring( value )
		end
	end
end

soundTimer = {}
killOtherTimer = {}
local screenSizex, screenSizey = guiGetScreenSize()
local guix = screenSizex * 0.1
local guiy = screenSizex * 0.1
local globalscale = 1
local globalalpha = 1
icon = {}
function createSoundForCar(car, horn)
	if isElement(icon[car]) then destroyElement(icon[car]) end
	if isTimer(soundTimer[car]) then killTimer(soundTimer[car]) end
	if isTimer(killOtherTimer[car]) then killTimer(killOtherTimer[car]) end
	icon[car] = guiCreateStaticImage(0, 0, guix, guiy, "icon.png", false )
	guiSetVisible(icon[car], false)
	local x,y,z = getElementPosition(car)
	local sound = playSound3D(horn, x, y, z, false)
	setSoundMaxDistance(sound, 150)
	local length = getSoundLength(sound)
	length = length * 1000
	soundTimer[car] = setTimer(function(sound, car)
		if not isElement(sound) or not isElement(car) then return end
		local rx,ry,rz = getElementPosition(car)
		setElementPosition(sound, rx, ry, rz)
		
		
		local playerx, playery, playerz = getElementPosition( getPedOccupiedVehicle(localPlayer) )
		cp_x, cp_y, cp_z = getElementPosition( car)
		local dist = getDistanceBetweenPoints3D ( cp_x, cp_y, cp_z, playerx, playery, playerz )
		if dist and dist < 40 and ( isLineOfSightClear(cp_x, cp_y, cp_z+1.2, playerx, playery, playerz, true, false, false, false )) then
			local screenX, screenY = getScreenFromWorldPosition ( cp_x, cp_y, cp_z+1.2 )
			local scaled = screenSizex * (1/(2*(dist+5))) *.85
			local relx, rely = scaled * globalscale, scaled * globalscale
			
			guiSetAlpha(icon[car], globalalpha)
			guiSetSize(icon[car], relx, rely, false)
			if(screenX and screenY) then
				guiSetPosition(icon[car], screenX, screenY, false)
				guiSetVisible(icon[car], true)
			else
				guiSetVisible(icon[car], false)
			end
		else
		 guiSetVisible(icon[car], false)
		end
		
		
		
	end, 50, 0, sound,car)
	
	killOtherTimer[car] = setTimer(function(theTimer, car) if isTimer(theTimer) then killTimer(theTimer) if isElement(icon[car]) then destroyElement(icon[car]) end end  end, length, 50, soundTimer[car], car)
end