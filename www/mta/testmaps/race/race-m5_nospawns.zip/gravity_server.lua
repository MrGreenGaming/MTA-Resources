grav_adjuster_1 = createColSphere(3654.4411621094, -1939.2885742188, 4804.6958007813, 19)
grav_adjuster_2 = createColSphere(3702.7658691406, -2388.2253417969, 4805.1743164063, 19)

function zone_enter ( thePlayer, matchingDimension )
        if getElementType ( thePlayer ) == "player" then
			inGravColCuboid = true
			triggerClientEvent("switchGravity", thePlayer, inGravColCuboid)
			local veh = getPedOccupiedVehicle(thePlayer)
			triggerClientEvent("setVehicleGravityPlease", root, veh)
        end
end
addEventHandler ( "onColShapeHit", grav_adjuster_1, zone_enter )
addEventHandler ( "onColShapeHit", grav_adjuster_2, zone_enter )

function zone_exit ( thePlayer, matchingDimension )
        if getElementType ( thePlayer ) == "player" then
			inGravColCuboid = false
			triggerClientEvent("switchGravity", thePlayer, inGravColCuboid)
        end
end
addEventHandler ( "onColShapeLeave", grav_adjuster_1, zone_exit )
addEventHandler ( "onColShapeLeave", grav_adjuster_2, zone_exit )