addEventHandler ('onClientResourceStart', resourceRoot, 
   function()
		setTimer(engineImportTXD, 2000, 1, engineLoadTXD ( 'txd.txd' ), 6342 )
		engineSetModelLODDistance(6342, 300)
		engineSetModelLODDistance(8838, 300)
		engineSetModelLODDistance(1681, 300)
		engineSetModelLODDistance(8131, 300)
		
		for k, object in ipairs(getElementsByType("object", resourceRoot)) do
		if getElementModel(object) == 6342 then
		x, y, z = getElementPosition(object)
		rx, ry, rz = getElementRotation(object)
		objLOD = createObject(6342, x, y, z, rx, ry, rz, true)
		setElementParent(objLOD, object)
		end
		end
     end
)