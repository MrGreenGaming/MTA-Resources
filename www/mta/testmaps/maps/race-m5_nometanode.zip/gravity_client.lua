g_Player = getLocalPlayer()
inGravColCuboid = false		-- If the player is in a field
symmetryHeight = 4805.70532226565

addEvent("setVehicleGravityPlease", true)
addEventHandler ("setVehicleGravityPlease", root, function (veh)
		local x, y, z = getElementPosition( veh )
		if (z > symmetryHeight) then
			setVehicleGravity ( veh, 0, 0,  -1 ) 
		else
			setVehicleGravity ( veh, 0, 0, 1 )
		end
end)

addEvent("switchGravity", true)
addEventHandler ("switchGravity", g_Player, function (toggleGravity)
	-- Toggle the gravity adjuster
	inGravColCuboid = toggleGravity
	-- Switch off/on collision
	local veh = getPedOccupiedVehicle ( g_Player )
	doForAllElements ( "vehicle", setElementCollidableWith, veh, not inGravColCuboid )
end)

addEventHandler ( "onClientRender", getRootElement(), function()
	local veh = getPedOccupiedVehicle ( g_Player )
	if inGravColCuboid then
		-- When in a gravity field, calculate and set the new gravity vector
		local vx, vy, vz = calculateGravity(veh, 1, 0, 1)
		setVehicleGravity ( veh , vx, vy, vz )
	elseif (veh) then
		-- Else check if we're in the upper or downer ring (with a vehicle) and check if gravity is correct, eles adjust gravity accordingly
		local x, y, z = getElementPosition( veh )
		local vx, vy, vz = getVehicleGravity ( veh )
		if (z > symmetryHeight) then
			if not ( vx == 0 and vy == 0 and vz ==  1) then setVehicleGravity ( veh, 0, 0,  1 ) end
		elseif not ( vx == 0 and vy == 0 and vz == -1) then setVehicleGravity ( veh, 0, 0, -1 )
		end
	end
end)

function calculateGravity( veh, mx, my, mz, mr )	-- Calculates the unity vector for a vehicle (veh), with relative components mx, my, mz and lentgh mr
	-- First some checks
	if getElementType(veh) ~= "vehicle" then return end
	if (not mr) then mr = 1 end
	-- Next is the vector beneath the vehicle
	local x1, y1, z1 = getElementPosition ( veh )
	local x2, y2, z2 = getPositionRelativeToElement( veh, 0, 0, -1 )
	local vx, vy, vz = x2 - x1, y2 - y1, z2 - z1
	-- Make the components relative
	vx, vy, vz= vx * mx, vy * my, vz * mz
	-- Get the unity vector
	local v = math.sqrt ( vx^2 + vy^2 + vz^2 )
	vx, vy, vz= vx / v, vy / v, vz / v
	-- Unity vector * length (mr) to get the desired length
	vx, vy, vz= vx * mr, vy * mr, vz * mr
	-- Return the final vector components
	return vx, vy, vz
end

function getPositionRelativeToElement(element, rx, ry, rz)
	-- Some magic
    local matrix = getElementMatrix (element)
    local offX = rx * matrix[1][1] + ry * matrix[2][1] + rz * matrix[3][1] + matrix[4][1]
    local offY = rx * matrix[1][2] + ry * matrix[2][2] + rz * matrix[3][2] + matrix[4][2]
    local offZ = rx * matrix[1][3] + ry * matrix[2][3] + rz * matrix[3][3] + matrix[4][3]
    return offX, offY, offZ
end

function doForAllElements ( elementType, theFunction, ... )
    local elementTable = getElementsByType ( elementType )
    for key, singleElement in pairs ( elementTable ) do
        theFunction ( singleElement, ... )
    end
end